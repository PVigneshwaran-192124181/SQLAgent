CREATE DATABASE IF NOT EXISTS sqlagent_db;
USE sqlagent_db;


CREATE TABLE IF NOT EXISTS employees (
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(100),
department VARCHAR(100),
salary DOUBLE,
joining_date DATE
);


INSERT INTO employ
2\. Create the database \& sample table (use MySQL Workbench or CLI). Run resources/sample-data.sql.



3\. Set your OpenAI API key as an environment variable (recommended):



&nbsp;   |   setx OPENAI\_API\_KEY "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxx"    |

&nbsp;   |  # then restart Eclipse/IDE                                |



(sk-proj-1uaS1y9r2bc\_rXgLZeDLGnNm9aeusJWvh355UY\_S7oIK0ESREtrIC05ouJDlSuYbYPtwxLuT9bT3BlbkFJoYH2-Z44o6y50Hap2oQ1wuVM3qhabsuFO0jiIRi1Vn2krXZQS8Bbr\_I-jDE739j-YOlK4bm\_cA)



4\. Configure DB credentials in DBConnect.java (URL, username, password) to match your MySQL setup.



5\. Build \& run in your IDE (Eclipse):



6\. Right-click project → Maven → Update Project



7\. Run AISQLAgent.java as Java Application



**Example queries to type at runtime:**



Show all employee names



* Show name and salary for employees in IT with salary > 70000
* Top 2 highest paid employees



***Files and purpose***



**DBConnect.java — JDBC connection helper.**



**SQLExecutor.java — Executes SQL and prints formatted results.**



**OpenAIClient.java — Calls OpenAI Chat Completion API to convert NL → SQL (uses environment var).**



**AISQLAgent.java — Main interactive console program.**



**TestConnection.java — Quick DB connection test.**



**resources/sample-data.sql — Schema and sample records.**


package com.sqlagent;


import java.util.Scanner;


public class AISQLAgent {
public static void main(String[] args) {
System.out.println("Welcome to AI SQL Agent! Type your questions about the database:\nType 'exit' to quit.\n");


String apiKey = System.getenv("OPENAI_API_KEY");
if (apiKey == null || apiKey.isEmpty()) {
System.out.println("OpenAI API key missing. Set OPENAI_API_KEY environment variable.");
return;
}


OpenAIClient client = new OpenAIClient(apiKey);
Scanner scanner = new Scanner(System.in);


while (true) {
System.out.print("You: ");
String input = scanner.nextLine();
if (input.equalsIgnoreCase("exit")) break;


String sql = client.getSQLQuery(input);
System.out.println("Generated SQL: " + sql);
SQLExecutor.executeQuery(sql);
}


scanner.close();
}
}
package com.sqlagent;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;


public class SQLExecutor {
public static void executeQuery(String query) {
if (query == null || query.trim().isEmpty()) {
System.out.println("No SQL to execute.");
return;
}


try (Connection con = DBConnect.getConnection();
Statement stmt = con.createStatement();
ResultSet rs = stmt.executeQuery(query)) {


int columnCount = rs.getMetaData().getColumnCount();


// Print column names
for (int i = 1; i <= columnCount; i++) {
System.out.print(rs.getMetaData().getColumnName(i) + "\t");
}
System.out.println();


Set<String> uniqueRows = new HashSet<>();
while (rs.next()) {
StringBuilder row = new StringBuilder();
for (int i = 1; i <= columnCount; i++) {
row.append(rs.getString(i)).append("\t");
}
String r = row.toString();
if (!uniqueRows.contains(r)) {
uniqueRows.add(r);
System.out.println(r);
}
}


} catch (Exception e) {
System.out.println("Error executing query: " + e.getMessage());
e.printStackTrace();
}
}
}
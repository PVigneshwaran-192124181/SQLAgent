package com.sqlagent;


import com.openai.client.OpenAI;
import com.openai.models.*;


import java.util.List;
import java.util.Optional;


public class OpenAIClient {
private final OpenAI client;


public OpenAIClient(String apiKey) {
this.client = OpenAI.builder().apiKey(apiKey).build();
}


public String getSQLQuery(String userInput) {
try {
String prompt = "Convert this natural language request into a MySQL query:\n" + userInput;


ChatCompletionCreateParams params = ChatCompletionCreateParams.builder()
.model("gpt-3.5-turbo")
.messages(List.of(
ChatCompletionMessageParam.of(ChatCompletionMessageRole.SYSTEM,
"You are a SQL expert. Convert user requests to correct MySQL queries."),
ChatCompletionMessageParam.of(ChatCompletionMessageRole.USER, prompt)
))
.temperature(0.0)
.build();


ChatCompletion completion = client.chatCompletions().create(params);
Optional<String> content = completion.choices().get(0).message().content();
return content.orElse(null);
} catch (Exception e) {
System.out.println("Error generating SQL: " + e.getMessage());
e.printStackTrace();
return null;
}
}
}